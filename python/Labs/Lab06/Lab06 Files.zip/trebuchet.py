# Author: Your name
# Date: Today's date
# Description: This program allows the user to enter in a number of distances
# that their trebuchet's projectile was thrown and then displays the top three
# distances to the user

#Variables storing the distance
distance1 = 0
distance2 = 0
distance3 = 0

#Variables storing the tirlas with the farthest distances
trial1 = 0
trial2 = 0
trial3 = 0

#Help determines if the user wishes to add in additional high distances
keepGoing = "Y"

trial = 1

#So long as keepGoing is Y, keep adding in more trials
while keepGoing == "Y":
    distance = int(input(f"Please enter your distance for trial {trial}: "))

    #If the new distance is farther than the farthest distance, replace it
    #and shift everything else down
    if distance > distance1:
        distance3 = distance2
        distance2 = distance1
        distance1 = distance        
        trial3 = trial2
        trial2 = trial1
        trial1 = trial
    #If the new distance is distance than the second distance distance, replace it
    #and shift everything else down    
    elif distance > distance2:
        distance3 = distance2
        distance2 = distance
        trial3 = trial2
        trial2 = trial
    #If the new distance is distance than the third distance distance, replace it    
    elif distance > distance3:
        distance3 = distance
        trial3 = trial

    keepGoing = input("Would you like to input another trial? (Y/N):")
    
    trial += 1

#Output the highest distances and the initials of those people
print("The top three distances for the trebuchet are:")
print("Trial Distance")
print("%5d %8d" % (trial1, distance1))
print("%5d %8d" % (trial2, distance2))
print("%5d %8d" % (trial3, distance3))
