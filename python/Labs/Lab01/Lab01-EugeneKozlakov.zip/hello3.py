#Author: Eugene Kozlakov
#Date: 9/3/2023
#Description: Putting together concepts from 'hello1.py' and 'hello2.py' to form a bigger program.

print('hello, world! :)')
userName = input("What's your name? (input!): ")
userAge = input("What is your age? (input!): ")
print(f"Hello, {userName}! You are {userAge} years old!")