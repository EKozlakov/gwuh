#Author: Eugene Kozlakov
#Date: 9/3/2023
#Description: basics+input

print('hello, world! :)')
userName = input("What's your name? (input!): ")
print(f"Hello, {userName}!")