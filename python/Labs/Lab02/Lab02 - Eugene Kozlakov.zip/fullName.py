#Author: Eugene Kozlakov
#Date: 9/10/2023
#Description: Intaking and outputting a user's first and last name.

firstName = input("What is your first name?: ")
lastName = input("What is your last name?: ")
print(f"Your name is: {lastName}, {firstName}")

quit() # to prevent terminal lockout, ensure program terminates