# Author: Your name
# Date: Today's date
# Description: Plays a position guessing game with the user. The
# user has to guess a point within a 10x10 grid.

partXPos = 4
partYPos = 6

#Prompt the user for a number between 1 and 10, inclusively
userXPos = int(input("The particle is somewhere in this space! What do you think its x coordinate is (1-10)? "))

#Prompt the user for a number between 1 and 10, inclusively
userYPos = int(input("What do you think its y coordinate is (1-10)? "))

#If the position is the same, tell the user they found the particle
if userXPos == partXPos and userYPos == partYPos:
    print("Good guess! (%d,%d) was the position!" % (partXPos,partYPos))
#If the number is outside of the range, tell the user they are outside the range
elif userXPos > 10 or userXPos < 1 or userYPos > 10 or userYPos < 1:
    print("No good! (%d,%d) is outside of the range!" % (userXPos,userYPos))
#Otherwise, tell the user they did not find it
else:
    print("Bad luck! (%d,%d) was the position!" % (partXPos,partYPos))
