#Author: Eugene Kozlakov
#Date: 9/3/2023
#Description: basics

print('hello, world! :)') 